from Homework_400 import function_1, function_2
function_1()
function_2()
